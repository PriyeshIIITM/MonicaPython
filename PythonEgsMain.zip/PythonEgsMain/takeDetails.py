print("Enter your details:")
name = input("Enter name here:")
age = int(input("Enter your age:"))
retirementLeft = 65 - age
sal = float(input("Enter your salary:"))

print("Hello " + name + " !")
print("Your age is", age, "and you have", retirementLeft, "yrs left before retirement")
print("Your current salary is: Rs." + str(sal))
