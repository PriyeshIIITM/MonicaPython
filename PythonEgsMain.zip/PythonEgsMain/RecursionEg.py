x=-1
while x<0:
    x=int(input("Enter a +ve number:"))


def sum(a):
    if(a==1):
        return 1
    else:
        return a + sum(a-1)


def fact(a):
    if(a<=1):
        return 1
    else:
        return a * fact(a-1)


ret = sum(x)

# ret = sum(4) = 4 + sum(3) = 4+3 + sum(2) =4+3+ 2+ sum(1) = 4+3+2+1
print(f"Sum of 1 to {x} is {ret}")


ret = fact(x)

# ret = fact(4) = 4 * fact(3) = .. =  4*3*2*1
print(f"Factorial of {x}! is {ret}")
