# if Statement Without else
number = int(input("Enter a number: "))
if number > 0:
    print("The number is positive.")
    print("Statement2")
# No action if the number is not positive


# Simple if...else
number = int(input("Enter another number: "))

if number % 2 == 0:
    print(f"{number} is even.")
else:
    print(f"{number} is odd.")


# Using if...elif...else
score = int(input("Enter your score: "))

if score >= 90:
    print("Grade: A")
elif score >= 80:
    print("Grade: B")
elif score >= 70:
    print("Grade: C")
elif score >= 60:
    print("Grade: D")
else:
    print("Grade: F")


# Nested if...else
age = int(input("Enter your age: "))
if age >= 18:
    if age >= 65:
        print("You are a senior citizen.")
    else:
        print("You are an adult.")
else:
    print("You are a minor.")

# Ternary Conditional Operator (Inline if...else)
temperature = int(input("Enter the temperature: "))
status = "Hot" if temperature > 30 else "Cold"
print(f"The weather is {status}.")



# Checking Multiple Conditions
age = int(input("Enter your age: "))
is_student = input("Are you a student? (yes/no): ").lower() == "yes"
is_weekend = input("Is it a weekend? (yes/no): ").lower() == "yes"

if (age < 18 or is_student) and not is_weekend:
    print("\nYou are eligible for a weekday student discount.")
else:
    print("\nYou are not eligible for the discount.")












