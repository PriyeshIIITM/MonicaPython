sum = lambda x, y :x+y

ret = sum(10,20)
print("Sum of 10 + 20 is ",ret)


def op(x,y, fn):
    return fn(x,y)


x=int(input("enter x:"))
y=int(input("enter y:"))

print(f"Sum : {x} + {y} : op(x,y,sum)" , op(x,y, lambda x,y : x+y))
print(f"Sub : {x} - {y} : op(x,y,sub)" , op(x,y, lambda x,y : x-y))
      



#the function table(n) prints the table of n    
def table(n):    
    return lambda a:a*n 

n = int(input("Enter the number:"))    

b = table(n) 
#the entered number is passed into the function table. b will now contain a lambda function

for i in range(1,11):    
    print(n,"X",i,"=",b(i)) 
#the lambda function b is called with the iteration variable i  


