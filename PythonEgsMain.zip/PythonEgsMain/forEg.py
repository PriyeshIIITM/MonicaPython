# Iterating through a list
fruits = ["apple", "banana", "cherry"]
for fruit in fruits:
    print(fruit)

# Using range() to generate a sequence of numbers
for i in range(1, 6):
    print(i)
print("Hellol")


for x in range(5, 0, -1):
    print (x)
print ("Blastoff!")



# Counting using a while loop
count = 1
while count <= 5:
    print(count)
    count += 1
print("While ends")


for i in range(1, 10):
    if i == 5:
        break
    print(i)
print("loop range(1,10) ends")

for i in range(1, 6):
    if i == 3:
        continue
    print(i)
print("loop range(1,6) ends")



for i in range(1, 4):
    print("\n")
    for j in range(1, 4):
        print(f"(i={i}, j={j})",end="       ")

print()



# Using pass in a for Loop
# If you plan to add code later but want the loop to exist for now, you can use pass.
for i in range(5):
    pass  # Placeholder for future code
print("Loop executed, but nothing happened!")

# Using pass in a while Loop
count = 0
while count < 5:
    pass  # Placeholder for future logic
    count += 1
print("While loop finished!")

# pass in Conditional Blocks within Loops
for i in range(5):
    if i % 2 == 0:
        pass  # Skip this step for now
    else:
        print(f"Odd number: {i}")





# 1. Searching for an Element in a List
numbers = [10, 20, 30, 40, 50]
target = 35
for num in numbers:
    if num == target:
        print(f"Found the target: {target}")
        break
else:
    print(f"Target {target} not found in the list.")
# 2. Prime Number Check
num = 29  # Change this to test with other numbers
for i in range(2, int(num**0.5) + 1):
    if num % i == 0:
        print(f"{num} is not a prime number. Divisible by {i}.")
        break
else:
    print(f"{num} is a prime number.")
# 3. Loop Completion Confirmation
for i in range(5):
    print(i)
else:
    print("Loop completed without interruption.")


