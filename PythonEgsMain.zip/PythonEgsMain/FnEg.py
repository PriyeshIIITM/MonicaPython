#function definition  
def hello_world():    
    print("hello world")    

def hello_Name():
    n=input("Enter your name")
    print("hello ", n)

def sm(a,b):
    print("Sum function")
    print(a+b)

def sm2(a,b):
    print("Sum 2 function")
    return (a+b)
    
# function calling  
# hello_world()
# hello_Name()

# sm(3,4)

#res = sm2(6,7)
# print(res)



a = 10  # global var becoz its outside any func
print("Before function call: ", a)

def printa():
    print(a) #using global var

def printa2():
    a=20 # local var inside a block
    print("Inside function call: ", a)


def printa3():
    global a  # global var used locally
    a=20
    print("Inside function call: ", a)

printa2()

print("After function call: ", a)
a=90

