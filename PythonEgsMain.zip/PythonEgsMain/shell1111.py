Python 3.13.5 (tags/v3.13.5:6cb20a2, Jun 11 2025, 16:15:46) [MSC v.1943 64 bit (AMD64)] on win32
Enter "help" below or click "Help" above for more information.
import keyword
print("The list of keywords is : "); print(keyword.kwlist)
The list of keywords is : 
['False', 'None', 'True', 'and', 'as', 'assert', 'async', 'await', 'break', 'class', 'continue', 'def', 'del', 'elif', 'else', 'except', 'finally', 'for', 'from', 'global', 'if', 'import', 'in', 'is', 'lambda', 'nonlocal', 'not', 'or', 'pass', 'raise', 'return', 'try', 'while', 'with', 'yield']
5>2
True
9>10
False
3>2 and 6>3
True
3>2 and 5>9
False
not 6>7
True
6>7
False
5>6 or 8>6
True
print("Hello")
Hello
print(5/2)
2.5
print(7+8)
15
print("Hello"+"World")
HelloWorld
print("Hello","World")
Hello World
print("Hello"); print("World")
Hello
World
x=10
type(x)
<class 'int'>
x=3+7j
type(x)
<class 'complex'>
x=5/2
type(x)
<class 'float'>

= RESTART: C:/Users/monica/AppData/Local/Programs/Python/Python313/PythonEgs/dataTypeEg.py
int_var: 10 | Type: <class 'int'>
float_var: 3.14 | Type: <class 'float'>
complex_var: (2+3j) | Type: <class 'complex'>
str_var: Hello, Python! | Type: <class 'str'>
list_var: [1, 2, 3, 4] | Type: <class 'list'>
tuple_var: (5, 6, 7, 8) | Type: <class 'tuple'>
range_var: [0, 1, 2, 3, 4] | Type: <class 'range'>
dict_var: {'name': 'Alice', 'age': 25} | Type: <class 'dict'>
set_var: {1, 2, 3, 4} | Type: <class 'set'>
frozenset_var: frozenset({8, 5, 6, 7}) | Type: <class 'frozenset'>
bool_var: True | Type: <class 'bool'>
bytes_var: b'hello' | Type: <class 'bytes'>
bytearray_var: bytearray(b'world') | Type: <class 'bytearray'>
memoryview_var: <memory at 0x000002CB2F62A680> | Type: <class 'memoryview'>
none_var: None | Type: <class 'NoneType'>
Print("Hello")
Traceback (most recent call last):
  File "<pyshell#21>", line 1, in <module>
    Print("Hello")
NameError: name 'Print' is not defined. Did you mean: 'print'?

= RESTART: C:/Users/monica/AppData/Local/Programs/Python/Python313/PythonEgs/dataTypeEg.py
int_var: 10 | Type: <class 'int'>
float_var: 3.14 | Type: <class 'float'>
complex_var: (2+3j) | Type: <class 'complex'>
str_var: Hello, Python! | Type: <class 'str'>
list_var: [1, 2, 3, 4] | Type: <class 'list'>
tuple_var: (5, 6, 7, 8) | Type: <class 'tuple'>
range_var: [0, 1, 2, 3, 4] | Type: <class 'range'>
dict_var: {'name': 'Alice', 'age': 25} | Type: <class 'dict'>
set_var: {1, 2, 3, 4} | Type: <class 'set'>
frozenset_var: frozenset({8, 5, 6, 7}) | Type: <class 'frozenset'>
bool_var: True | Type: <class 'bool'>
bytes_var: b'hello' | Type: <class 'bytes'>
bytearray_var: bytearray(b'world') | Type: <class 'bytearray'>
memoryview_var: <memory at 0x00000290E71CA680> | Type: <class 'memoryview'>
none_var: None | Type: <class 'NoneType'>

= RESTART: C:/Users/monica/AppData/Local/Programs/Python/Python313/PythonEgs/dataTypeEg.py
int_var: 10 | Type: <class 'int'>
float_var: 3.14 | Type: <class 'float'>
complex_var: (2+3j) | Type: <class 'complex'>
str_var: Hello, Python! | Type: <class 'str'>
list_var: [1, 2, 3, 4] | Type: <class 'list'>
tuple_var: (5, 6, 7, 8) | Type: <class 'tuple'>
range_var: [0, 1, 2, 3, 4] | Type: <class 'range'>
dict_var: {'name': 'Alice', 'age': 25} | Type: <class 'dict'>
set_var: {1, 2, 3, 4} | Type: <class 'set'>
frozenset_var: frozenset({8, 5, 6, 7}) | Type: <class 'frozenset'>
bool_var: True | Type: <class 'bool'>
bytes_var: b'hello' | Type: <class 'bytes'>
bytearray_var: bytearray(b'world') | Type: <class 'bytearray'>
memoryview_var: <memory at 0x000002066AA3A680> | Type: <class 'memoryview'>
none_var: None | Type: <class 'NoneType'>
print(int_var)
10
print(int_var123)
Traceback (most recent call last):
  File "<pyshell#23>", line 1, in <module>
    print(int_var123)
NameError: name 'int_var123' is not defined. Did you mean: 'int_var'?
3+5
8
4-2
2
6*3
18
7%3
1
4**2
16
2+2/2
3.0
5==5
True
5==6
False
6<10
True
6<=10
True
6<=6
True
6>=10
False
6>3
True
6!=8
True
6<>8
SyntaxError: invalid syntax
6!=8
True
5/2
2.5
5//2
2








x=10
x += 20
x
30
x = x + 20
x
50
a = [1,2,3,4]
a
[1, 2, 3, 4]
a.reverse()
a
[4, 3, 2, 1]
1 in a
True
7 in a
False
3 not in a
False
7 not in a
True
x=5
type(x)
<class 'int'>
type(x) is 'int'
False
type(x) is int
True
x=5
y=x
y is x
True
z=5
x == y
True
x == z
True
x is z
True
a = [1,2]
b=a
a
[1, 2]
b
[1, 2]
c = [1,2]
c
[1, 2]
a == b
True
a == c
True
a is b
True
a is c
False
5 = 6
SyntaxError: cannot assign to literal here. Maybe you meant '==' instead of '='?
x = 6
x
6
5 == 6
False
x == 6
True
id(a)
2226583146944
id(b)
2226583146944
id(c)
2226583288512
a.reverse()
a
[2, 1]
b
[2, 1]
c
[1, 2]
a=[1,2]
c=[1,2]
a==c
True
a is c
False
id(a)
2226583146496
id(c)
2226538790016
b=a
id(b)
2226583146496
a is b
True
a ==b
True
a =10
b=20
maxm = a if a>b else b
maxm
20
print("a=",a,"b=",b,"min=",(a if a<b else b))
a= 10 b= 20 min= 10

= RESTART: C:/Users/monica/AppData/Local/Programs/Python/Python313/PythonEgs/takeDetails.py
Enter your details:
Enter name here:John
Hello John !

= RESTART: C:/Users/monica/AppData/Local/Programs/Python/Python313/PythonEgs/takeDetails.py
Enter your details:
Enter name here:John
Enter your age:60
Traceback (most recent call last):
  File "C:/Users/monica/AppData/Local/Programs/Python/Python313/PythonEgs/takeDetails.py", line 4, in <module>
    retirementLeft = 65 - age
TypeError: unsupported operand type(s) for -: 'int' and 'str'

= RESTART: C:/Users/monica/AppData/Local/Programs/Python/Python313/PythonEgs/takeDetails.py
Enter your details:
Enter name here:John
Enter your age:60
Hello John !

= RESTART: C:/Users/monica/AppData/Local/Programs/Python/Python313/PythonEgs/takeDetails.py
Enter your details:
Enter name here:John
Enter your age:60
Traceback (most recent call last):
  File "C:/Users/monica/AppData/Local/Programs/Python/Python313/PythonEgs/takeDetails.py", line 5, in <module>
    sal = float(intput("Enter your salary:"))
NameError: name 'intput' is not defined. Did you mean: 'input'?

= RESTART: C:/Users/monica/AppData/Local/Programs/Python/Python313/PythonEgs/takeDetails.py
Enter your details:
Enter name here:John
Enter your age:60
Enter your salary:1134.9
Hello John !
Your age is 60 and you have 5 yrs left before retirement
Your current salary is:  1134.9

= RESTART: C:/Users/monica/AppData/Local/Programs/Python/Python313/PythonEgs/takeDetails.py
Enter your details:
Enter name here:J
Enter your age:60
Enter your salary:45.9
Hello J !
Your age is 60 and you have 5 yrs left before retirement
Traceback (most recent call last):
  File "C:/Users/monica/AppData/Local/Programs/Python/Python313/PythonEgs/takeDetails.py", line 9, in <module>
    print("Your current salary is: Rs." + sal)
TypeError: can only concatenate str (not "float") to str

= RESTART: C:/Users/monica/AppData/Local/Programs/Python/Python313/PythonEgs/takeDetails.py
Enter your details:
Enter name here:J
Enter your age:60
Enter your salary:45.9
Hello J !
Your age is 60 and you have 5 yrs left before retirement
Your current salary is: Rs.45.9
a=[1,2,3,4]
type(a)
<class 'list'>
print("List data type:"); b=list(input("Enter a list"))
List data type:
Enter a list1234
b
['1', '2', '3', '4']
a=[1,2,3,4]
a.append(5)
a
[1, 2, 3, 4, 5]
a = tuple(a)
a
(1, 2, 3, 4, 5)
a.append(6)
Traceback (most recent call last):
  File "<pyshell#120>", line 1, in <module>
    a.append(6)
AttributeError: 'tuple' object has no attribute 'append'
a = list(a)
a.append(6)
a
[1, 2, 3, 4, 5, 6]
emp = {'name':'John','age':60,'salary':1234.9}
emp
{'name': 'John', 'age': 60, 'salary': 1234.9}
emp['age']
60
emp['age'] = 90
emp
{'name': 'John', 'age': 90, 'salary': 1234.9}
emp['designation'] = 'Coder'
emp
{'name': 'John', 'age': 90, 'salary': 1234.9, 'designation': 'Coder'}
a={1,2,3}
type(emp)
<class 'dict'>
type(a)
<class 'set'>
a = {1,2,3,4,4,5}
a
{1, 2, 3, 4, 5}
a="Hello"
b='World'
a+b
'HelloWorld'
a * 3
'HelloHelloHello'
a=[1,2,3]
b=[4,5,6]
a+b
[1, 2, 3, 4, 5, 6]
a
[1, 2, 3]
b
[4, 5, 6]
a += b
a
[1, 2, 3, 4, 5, 6]
a * 3
[1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5, 6]
b=a.copy()
b
[1, 2, 3, 4, 5, 6]
a
[1, 2, 3, 4, 5, 6]
id(a)
2021273997312
id(b)
2021229509760
c=a
id(c)
2021273997312
len(a)
6
min(a)
1
max(a)
6
sum(a)
21
a.append(1)
a
[1, 2, 3, 4, 5, 6, 1]
b=[8,9]
a.extend(b)
a
[1, 2, 3, 4, 5, 6, 1, 8, 9]
a.insert(9,4)
a
[1, 2, 3, 4, 5, 6, 1, 8, 9, 4]
a.insert(3,8)
a
[1, 2, 3, 8, 4, 5, 6, 1, 8, 9, 4]
a.pop(2)
3
a
[1, 2, 8, 4, 5, 6, 1, 8, 9, 4]
a.remove(1)
a
[2, 8, 4, 5, 6, 1, 8, 9, 4]
a[6]
8
a.index(6)
4
a.append(8)
a
[2, 8, 4, 5, 6, 1, 8, 9, 4, 8]
a.count(8)
3
a.sort()
a
[1, 2, 4, 4, 5, 6, 8, 8, 8, 9]
a
[1, 2, 4, 4, 5, 6, 8, 8, 8, 9]
a.clear()
a
[]
h
Traceback (most recent call last):
  File "<pyshell#182>", line 1, in <module>
    h
NameError: name 'h' is not defined
a
[]
del a
a
Traceback (most recent call last):
  File "<pyshell#185>", line 1, in <module>
    a
NameError: name 'a' is not defined
a = [1,2,3,4,5,6,7,8,9]
a
[1, 2, 3, 4, 5, 6, 7, 8, 9]
a[:3]
[1, 2, 3]
a[3:7]
[4, 5, 6, 7]
a[5:]
[6, 7, 8, 9]
a[2:8:1]
[3, 4, 5, 6, 7, 8]
a[2:8:2]
[3, 5, 7]

= RESTART: C:/Users/monica/AppData/Local/Programs/Python/Python313/PythonEgs/listEg.py
Original List: [10, 20, 30, 40, 50]

Properties:
Length of list: 5
Minimum value in the list: 10
Maximum value in the list: 50
Sum of all elements in the list: 150

Operations:
After appending 60: [10, 20, 30, 40, 50, 60]
After extending with [70, 80]: [10, 20, 30, 40, 50, 60, 70, 80]
After inserting 25 at index 2: [10, 20, 25, 30, 40, 50, 60, 70, 80]
After popping value at index 3: [10, 20, 25, 40, 50, 60, 70, 80]
Popped value: 30
After removing 25: [10, 20, 40, 50, 60, 70, 80]
Index of 40: 2
Count of 40: 1
After reversing the list: [80, 70, 60, 50, 40, 20, 10]
After sorting the list: [10, 20, 40, 50, 60, 70, 80]

Slicing:
First three elements: [10, 20, 40]
Elements from index 2 to 5: [40, 50, 60]
Last three elements: [60, 70, 80]

Concatenation and Repetition:
Concatenated list: [10, 20, 40, 50, 60, 70, 80, 100, 200]
Repeated list: [10, 20, 40, 50, 60, 70, 80, 10, 20, 40, 50, 60, 70, 80]

List Comprehension:
Squares of elements: [100, 400, 1600, 2500, 3600, 4900, 6400]

Copying:
Copied list: [10, 20, 40, 50, 60, 70, 80]
After clearing the list: []
a=10
type(a)
<class 'int'>
a = 10,
type(a)
<class 'tuple'>
a = (10,)
a=(6)
type(a)
<class 'int'>
a = (10,)

type(a)
<class 'tuple'>
a=(10,20)
c,d = a
c
10
d
20
type(a)
<class 'tuple'>
type(c)
<class 'int'>
a, b = 10, 20
a
10
b
20
a=[1,2,3]
a[0]=9
a
[9, 2, 3]
a=(1,2,3)
a[0]
1
a[0]=9
Traceback (most recent call last):
  File "<pyshell#217>", line 1, in <module>
    a[0]=9
TypeError: 'tuple' object does not support item assignment

= RESTART: C:/Users/monica/AppData/Local/Programs/Python/Python313/PythonEgs/tupleEg.py
Original Tuple: (10, 20, 30, 40, 50, 20)

Properties:
Length of tuple: 6
Minimum value in the tuple: 10
Maximum value in the tuple: 50
Sum of all elements in the tuple: 170

Accessing Elements:
First element: 10
Last element: 20
Slice from index 1 to 3: (20, 30, 40)
Every second element: (10, 30, 50)

Concatenation and Repetition:
Concatenated tuple: (10, 20, 30, 40, 50, 20, 20, 60, 70)
Repeated tuple: (10, 20, 30, 40, 50, 20, 10, 20, 30, 40, 50, 20)

Tuple Methods:
Count of 20 in tuple: 2
Index of 30 in tuple: 2

Unpacking Tuples:
Unpacked values: 10 20 30 40 50 20

Nested Tuple: ((10, 20, 30, 40, 50, 20), (20, 60, 70))

Membership Tests:
Is 20 in the tuple? True
Is 100 not in the tuple? True

Immutability:
Error: 'tuple' object does not support item assignment
a={1,5,2,8}
a
{8, 1, 2, 5}
a={10,20,50}
a
{10, 20, 50}

= RESTART: C:/Users/monica/AppData/Local/Programs/Python/Python313/PythonEgs/setEg.py
Original set: {50, 20, 40, 10, 30}
After adding 60: {50, 20, 40, 10, 60, 30}
After removing 20: {50, 40, 10, 60, 30}
After discarding 100: {50, 40, 10, 60, 30}
Popped element: 50
After popping an element: {40, 10, 60, 30}
After clearing the set: set()
Union of sets: {70, 40, 10, 50, 20, 60, 30}
Intersection of sets: {40, 50, 30}
Difference of sets: {10, 20}
Symmetric difference of sets: {20, 70, 10, 60}
Is disjoint with yet_another_set? True
Is my_set a subset of union_set? True
Is union_set a superset of my_set? True
Copied set: {50, 20, 40, 10, 30}
After updating my_set with another_set: {70, 40, 10, 50, 20, 60, 30}
After intersection_update with another_set: {70, 40, 50, 60, 30}
After difference_update with another_set: set()
After symmetric_difference_update with another_set: {70, 40, 50, 60, 30}
Length of my_set: 5
Is 20 in my_set? True
Is 100 not in my_set? True
Union using |: {70, 40, 10, 50, 20, 60, 30}
Intersection using &: {40, 50, 30}
Difference using -: {10, 20}
Symmetric difference using ^: {20, 70, 10, 60}

= RESTART: C:/Users/monica/AppData/Local/Programs/Python/Python313/PythonEgs/ifEg.py
Enter a number: -7
Enter another number: 5
5 is odd.

= RESTART: C:/Users/monica/AppData/Local/Programs/Python/Python313/PythonEgs/ifEg.py
Enter a number: 4
The number is positive.
Statement2
Enter another number: 6
6 is even.

= RESTART: C:/Users/monica/AppData/Local/Programs/Python/Python313/PythonEgs/ifEg.py
Enter a number: 4
The number is positive.
Statement2
Enter another number: 4
4 is even.
Enter your score: 90
Grade: A

= RESTART: C:/Users/monica/AppData/Local/Programs/Python/Python313/PythonEgs/ifEg.py
Enter a number: 4
The number is positive.
Statement2
Enter another number: 4
4 is even.
Enter your score: 89
Grade: B
Enter your age: 90
You are a senior citizen.
Enter the temperature: 40
The weather is Hot.

= RESTART: C:/Users/monica/AppData/Local/Programs/Python/Python313/PythonEgs/ifEg.py
Enter a number: 4
The number is positive.
Statement2
Enter another number: 5
5 is odd.
Enter your score: 4
Grade: F
Enter your age: 5
You are a minor.
Enter the temperature: 5
The weather is Cold.
Enter your age: 20
Are you a student? (yes/no): yes
Is it a weekend? (yes/no): no

You are eligible for a weekday student discount.
>>> range(1,6)
range(1, 6)
>>> list(range(1,6))
[1, 2, 3, 4, 5]
>>> 
= RESTART: C:/Users/monica/AppData/Local/Programs/Python/Python313/PythonEgs/forEg.py
apple
banana
cherry
1
2
3
4
5
print("Aaa")
