n=""
a=0
while(True):
    print("\n*****Menu*****")
    print("1. Enter name\n2.Enter Age\n3.Display Details\n4.Exit")
    ch=int(input("Enter the choice:"))
    if(ch==1):
        n=input("Enter your name")
    elif(ch==2):
        a=int(input("Enter your age"))
    elif(ch==3):
        print(f"Name: {n}, and age: {a}")
    elif(ch==4):
        break
    else:
        print("Invalid choice")

print("Menu ends")
