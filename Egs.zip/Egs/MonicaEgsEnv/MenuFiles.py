import csv, json
import xml.etree.ElementTree as ET

def read_csv(filename):
    with open(filename, 'r') as f:
        reader = csv.reader(f)
        for row in reader:
            print(row)

def write_csv(filename):
    with open(filename, 'w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(['Name', 'Age'])
        writer.writerow(['Alice', '30'])
        writer.writerow(['Bob', '25'])

def read_tsv(filename):
    with open(filename, 'r') as f:
        reader = csv.reader(f, delimiter='\t')
        for row in reader:
            print(row)

def write_tsv(filename):
    with open(filename, 'w', newline='') as f:
        writer = csv.writer(f, delimiter='\t')
        writer.writerow(['Name', 'Age'])
        writer.writerow(['Tom', '22'])
        writer.writerow(['Jerry', '21'])

def read_json(filename):
    with open(filename, 'r') as f:
        data = json.load(f)
        print(json.dumps(data, indent=4))

def write_json(filename):
    data = {
        "employees": [
            {"name": "Alice", "age": 30},
            {"name": "Bob", "age": 25}
        ]
    }
    with open(filename, 'w') as f:
        json.dump(data, f, indent=4)

def read_xml(filename):
    tree = ET.parse(filename)
    root = tree.getroot()
    for person in root.findall("person"):
        print(person.attrib)

def write_xml(filename):
    root = ET.Element("people")
    ET.SubElement(root, "person", name="Alice", age="30")
    ET.SubElement(root, "person", name="Bob", age="25")
    tree = ET.ElementTree(root)
    tree.write(filename)

def menu():
    while True:
        print("\n--- File Handling Menu ---")
        print("1. Read CSV")
        print("2. Write CSV")
        print("3. Read TSV")
        print("4. Write TSV")
        print("5. Read JSON")
        print("6. Write JSON")
        print("7. Read XML")
        print("8. Write XML")
        print("9. Exit")

        choice = input("Enter your choice: ")

        match choice:
            case '1': read_csv("data.csv")
            case '2': write_csv("data.csv")
            case '3': read_tsv("data.tsv")
            case '4': write_tsv("data.tsv")
            case '5': read_json("data.json")
            case '6': write_json("data.json")
            case '7': read_xml("data.xml")
            case '8': write_xml("data.xml")
            case '9': print("Exiting..."); break
            case _: print("Invalid choice. Try again.")

menu()
