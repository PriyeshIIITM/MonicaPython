import csv

data = [['Name', 'Age'], ['Alice', 30], ['Bob', 25]]

with open('output.csv', mode='w', newline='') as file:
    writer = csv.writer(file)
    writer.writerows(data)
