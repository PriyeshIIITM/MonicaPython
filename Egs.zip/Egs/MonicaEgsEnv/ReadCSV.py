# Reading an XML File
import xml.etree.ElementTree as ET

tree = ET.parse('data.xml')
root = tree.getroot()
for child in root:
    print(child.tag, child.attrib)

# Writing to an XML File
# import xml.etree.ElementTree as ET

root = ET.Element("people")
person = ET.SubElement(root, "person", name="Alice", age="30")
tree = ET.ElementTree(root)
tree.write("output.xml")
