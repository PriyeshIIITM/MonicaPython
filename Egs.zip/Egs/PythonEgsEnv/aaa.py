"""This module prints a greeting."""


def say_hello(name):
    """Greet the user by name."""
    print("Hello " + name)


say_hello("Alice")

