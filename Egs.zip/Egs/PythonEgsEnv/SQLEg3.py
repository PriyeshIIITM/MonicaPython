import pandas as pd
import pyodbc
import warnings

warnings.filterwarnings("ignore", message=".*pandas only supports SQLAlchemy.*")

# 1. Connect to SQL Server
conn = pyodbc.connect(
    'DRIVER={ODBC Driver 18 for SQL Server};'
    'SERVER=localhost;DATABASE=pythondb;Trusted_Connection=yes;TrustServerCertificate=yes;'
)

# 2. SQL Query
query = "SELECT * FROM emptbl"

# 3. Load data into a pandas DataFrame
df = pd.read_sql(query, conn)

# 4. Write DataFrame to Excel
df.to_excel("EmployeeData.xlsx", index=False, engine='openpyxl')

print("Data written to 'EmployeeDataBase.xlsx'")
# Data written to 'EmployeeDataBase.xlsx'
