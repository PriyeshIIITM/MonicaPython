import platform
# 1. Get OS Name
print(platform.system()) # Windows
# Windows # Linux # Darwin  # macOS
# 2. Get Full OS Details
print(platform.platform()) # Windows-10-10.0.19045-SP0
# Windows-10-10.0.19045-SP0 # Linux-5.15.0-105-generic-x86_64-with-glibc2.29
# 3. Get Python Version
print(platform.python_version())   # '3.13.5'
print(platform.python_implementation())  # 'CPython'
# 4. Get Machine Architecture
print(platform.machine())    # 'AMD64', 'x86_64'  # AMD64
print(platform.architecture())  # ('64bit', 'WindowsPE')
# 5. Get Processor Info
print(platform.processor())  # Intel64 Family 6 Model 140 Stepping 2, GenuineIntel
# 6. Get Node (Computer) Name
print(platform.node())  # DESKTOP-PSCP60H
# 7. All Info in One Shot
print("Platform:", platform.platform()) # Platform: Windows-10-10.0.19045-SP0
print("System:", platform.system())     # System: Windows
print("Release:", platform.release())   # Release: 10
print("Version:", platform.version())   # Version: 10.0.19045
print("Machine:", platform.machine())   # Machine: AMD64
print("Processor:", platform.processor()) # Processor: Intel64 Family 6 Model 140 Stepping 2, GenuineIntel
print("Python Version:", platform.python_version()) # Python Version: 3.13.5

