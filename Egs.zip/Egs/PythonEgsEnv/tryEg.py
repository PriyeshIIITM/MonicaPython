def fn():
    try:    
        a = int(input("Enter a:"))    
        b = int(input("Enter b:"))    
        c = a/b  
        print(f"{a}/{b} = {c}")    
    # Using Exception with except statement.  
    except Exception as e:    
        print("Error has happened, details: ")    
        print(e)  
    else:    
        print("Hi I am else block, I will run when try is fully successful")     
    finally:
        print("Hi I am finally block, I will run always")


##try:    
##    age = int(input("Enter the age:"))    
##    if(age<18):    
##        raise ValueError   
##    else:    
##        print("The age is valid")    
##except ValueError:    
##    print("The age is not valid")
##
####Output:    
####Enter the age:10
####The age is not valid

try:  
     num = int(input("Enter a positive integer: "))  
     if(num <= 0):  
         # we can pass the message in the raise statement  
         raise ValueError("That is  a negative number!")  
except ValueError as e:  
     print(e)  

##Output:
##Enter a positive integer: -5
##That is a negative number!







    
