import csv
# Reading from a CSV File # 1. Using csv.reader
with open('data.csv', 'r') as file:
    reader = csv.reader(file)
    for row in reader:
        print(row)
# 2. Using csv.DictReader (reads into dictionaries)
with open('data.csv', 'r') as file:
    reader = csv.DictReader(file)
    for row in reader:
        print(row)

# Writing to a CSV File # 1. Using csv.writer
data = [['Name', 'Age'], ['Tom', 23], ['Jerry', 24]]
with open('output.csv', 'w', newline='') as file:
    writer = csv.writer(file)
    writer.writerows(data)
# 2. Using csv.DictWriter
data = [
    {'Name': 'Tom', 'Age': 23},
    {'Name': 'Jerry', 'Age': 24}
]
with open('output_dict.csv', 'w', newline='') as file:
    fieldnames = ['Name', 'Age']
    writer = csv.DictWriter(file, fieldnames=fieldnames)
    writer.writeheader()
    writer.writerows(data)

# Custom Delimiters (e.g., for TSV)
with open('data.tsv', 'r') as file:
    reader = csv.reader(file, delimiter='\t')
    for row in reader:
        print(row)

