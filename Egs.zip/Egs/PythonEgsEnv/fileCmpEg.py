import filecmp
# 1. Compare Two Files
file1, file2 = "file_a.txt" , "file_b.txt"
# Compare files (shallow=True checks only metadata)
# shallow=True (default): Compares only file metadata (size, modified time)
# shallow=False: Compares file contents byte-by-byte
are_same = filecmp.cmp(file1, file2, shallow=False) 
print("Files are equal:", are_same) # Files are equal: True
# 2. Compare Lists of Files in Two Directories
dir1, dir2 = "folder1",  "folder2"
common_files = ["a.txt", "b.txt", "c.txt"]
match, mismatch, errors = filecmp.cmpfiles(dir1, dir2, common_files, shallow=False)
print("Matched files:", match) # Matched files: ['a.txt']
print("Mismatched files:", mismatch) # Mismatched files: ['b.txt']
print("Files with errors:", errors) # Files with errors: ['c.txt']
# 3. Detailed Directory Comparison with dircmp
cmp_obj = filecmp.dircmp("folder1", "folder2")
print("Common files:", cmp_obj.common_files)  # Files present in both # Common files: ['a.txt', 'b.txt']
print("Only in folder1:", cmp_obj.left_only) # Files only in folder1 # Only in folder1: ['c.txt']
print("Only in folder2:", cmp_obj.right_only) # Files only in folder2 # Only in folder2: ['d.txt']
print("Mismatched files:", cmp_obj.diff_files) # Mismatched files # Mismatched files: ['b.txt']
# 4. Recursive Comparison of Subdirectories # Outputs a detailed recursive comparison of all subdirectories and files.
cmp_obj.report_full_closure() # diff folder1 folder2 # Only in folder1 : ['c.txt'] # Only in folder2 : ['d.txt']
# Identical files : ['a.txt'] # Differing files : ['b.txt’] 
