from openpyxl import Workbook

wb = Workbook()                       # Create a new workbook
ws = wb.active                       # Get the active sheet
ws.title = "EmployeeData"

# Write headers
ws.append(["EmpID", "Name", "Salary", "Branch"])

# Add some data
ws.append([101, "Ravi", 55000, "IT"])
ws.append([102, "Anita", 60000, "HR"])

# Save the workbook
wb.save("employee1.xlsx")
print("Excel file 'employee1.xlsx' created.")
# Excel file 'employee1.xlsx' created.
