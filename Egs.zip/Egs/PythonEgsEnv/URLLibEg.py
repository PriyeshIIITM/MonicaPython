import urllib.request, urllib.parse, urllib.error
import ssl
import json

# Optional: Avoid SSL errors (for testing only)
context = ssl._create_unverified_context()

print("\n 1. GET REQUEST with URL Params")
base_url = "https://jsonplaceholder.typicode.com/comments"
params = urllib.parse.urlencode({'postId': 1})
url = f"{base_url}?{params}"

try:
    with urllib.request.urlopen(url, context=context) as response:
        data = json.loads(response.read())
        for i in range(0,5):
            print("Comment Name:", data[i]["name"])  # print first 5 comment name
except urllib.error.HTTPError as e:
    print("HTTP Error:", e.code)
except urllib.error.URLError as e:
    print("URL Error:", e.reason)

print("\n 2. POST REQUEST with Encoded Form Data")
post_url = "https://httpbin.org/post"
post_data = urllib.parse.urlencode({
    'username': 'JohnDoe',
    'password': 'abc123'
}).encode("utf-8")

try:
    req = urllib.request.Request(post_url, data=post_data)
    with urllib.request.urlopen(req, context=context) as response:
        result = json.loads(response.read())
        print("Posted Data:", result["form"])
except urllib.error.URLError as e:
    print("POST Failed:", e.reason)


print("\n 3. GET with HEADERS")
url_with_headers = "https://httpbin.org/headers"
headers = {
    'User-Agent': 'Mozilla/5.0 (Python Script)',
    'X-Custom-Header': 'Demo123'
}
req = urllib.request.Request(url_with_headers, headers=headers)

try:
    with urllib.request.urlopen(req, context=context) as response:
        result = json.loads(response.read())
        print("Received Headers:\n", result["headers"])
except urllib.error.URLError as e:
    print("Header request failed:", e.reason)


print("\n 4. DOWNLOAD FILE")
file_url = "https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf"
file_name = "downloaded_sample.pdf"

try:
    urllib.request.urlretrieve(file_url, file_name)
    print("File downloaded successfully:", file_name)
except urllib.error.URLError as e:
    print("Download failed:", e.reason)

