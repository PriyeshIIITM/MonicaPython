import requests
# POST Request with Data and Headers
response = requests.post("https://httpbin.org/post", data={"name": "Alice"})
print("\nPosting data={name: Alice} to https://httpbin.org/post : \n")
print(response.json())
myheaders = {"User-Agent": "my-python-script"}
r = requests.get("https://httpbin.org/headers", headers=myheaders)
print("\nSending Headers = {User-Agent: my-python-script} to https://httpbin.org/headers : \n")
print(r.text)
# Response Object Details
print("\nPosting data and headers to https://httpbin.org/post : Gives following response: \n")
print("response.status_code: \n", response.status_code)   # 200 (OK), 404 (Not Found), etc.
print("response.headers: \n", response.headers)       # All response headers
print("response.url: \n", response.url)           # Final URL after redirects
print("response.content: \n", response.content)       # Raw bytes
print("response.text: \n", response.text)          # Decoded string
print("response.json(): \n", response.json())        # Parsed JSON (if applicable)

