class Employee:  
    __count = 0;   # private fields, cannot be accessed directly outside of a class 
    def __init__(self):  
        Employee.__count = Employee.__count+1  
    def display(self):  
        print("The number of employees",Employee.__count)  

emp = Employee()  
emp2 = Employee()  
#print(emp.__count)  
emp.display()  
print(Employee.__dict__)
print(emp._Employee__count)
