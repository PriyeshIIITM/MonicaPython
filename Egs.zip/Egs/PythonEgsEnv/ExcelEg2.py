from openpyxl import load_workbook

# Reading from an Excel File
wb = load_workbook("employee1.xlsx")
ws = wb.active

# Read all rows
print("Excel Data:")
for row in ws.iter_rows(values_only=True):
    print(row)

# Accessing Individual Cells
print("A1 =", ws["A1"].value)       # Access specific cell
print("B2 =", ws.cell(row=2, column=2).value)

# Modifying an Existing Excel File
ws["C2"] = 58000                   # Update salary for EmpID 101
ws.append([103, "Sita", 62000, "Finance"])  # Add a new row
wb.save("employee1.xlsx")
print("Data updated in 'employee1.xlsx'")

# Formatting Cells (Optional)
from openpyxl.styles import Font, Alignment

ws["A1"].font = Font(bold=True, color="0000FF")
ws["A1"].alignment = Alignment(horizontal="center")
wb.save("employee1.xlsx")

