print("1. Simple List from range()")
nums = [x for x in range(5)]
print(nums)  # [0, 1, 2, 3, 4]
print("2. With Condition (Filter Even Numbers)")
evens = [x for x in range(10) if x % 2 == 0]
print(evens)  # [0, 2, 4, 6, 8]
print(" 3. Apply Function (Square Each Number)")
squares = [x**2 for x in range(5)]
print(squares)  # [0, 1, 4, 9, 16]
print(" 4. Using if-else in Expression")
result = ['even' if x % 2 == 0 else 'odd' for x in range(5)]
print(result)  # ['even', 'odd', 'even', 'odd', 'even']
print(" 5. Nested Loops")
pairs = [(x, y) for x in [1, 2] for y in [3, 4]]
print(pairs)  # [(1, 3), (1, 4), (2, 3), (2, 4)]
print(" 6. Flatten a 2D List")
matrix = [[1, 2], [3, 4]]
flat = [num for row in matrix for num in row]
print(flat)  # [1, 2, 3, 4]
print(" 7. With String Data")
chars = [c.upper() for c in "hello"]
print(chars)  # ['H', 'E', 'L', 'L', 'O']
print(" 8. Using Functions in List Comprehensions")
def square(x): return x * x
squares = [square(i) for i in range(5)]
print(squares)  # [0, 1, 4, 9, 16]
print("9. Equivalent with for Loop")
squares = [x**2 for x in range(5)]
print(squares)
print(" 10. Using Lambdas in List Comprehensions")
squares = [(lambda x:x*x)(i) for i in range(5)]
print(squares)  # [0, 1, 4, 9, 16]
