class Student:  
    # Constructor - non parameterized  
    def __init__(self):  
        print("This is non parametrized constructor")  
    def show(self,name):
        self.name=name
        print("Hello",name)
    def display(self):
         print("Hello",self.name)


print("Student Constructed")
student = Student()
print("Show Called")
student.show("John")
student.display()


class Student1:  
    # Constructor - non parameterized  
    def __init__(self):  
        print("This is non parametrized constructor")  
    def show(self,name):
        print("Hello",name)
    def display(self):
         print("Hello",name)

print("Student Constructed")
student = Student1()
print("Show Called")
student.show("John")
student.display()
