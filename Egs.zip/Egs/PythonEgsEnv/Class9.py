# If an object “quacks like a duck,” it can be used like a duck. : Called Duck Typing
class Dog:
    def speak(self):
        print("Woof!")
    def move(self):
        print("run")

class Parrot:
    def speak(self):
        print("tweek!")
    def fly(self):
        print("Fly High")
        
def work(animal):
    animal.speak()
    if isinstance(animal,Dog):
        animal.move()
    elif isinstance(animal,Parrot):
        animal.fly()
    else:
        print("IDK..")

    
work(Dog())  # Woof!
work(Parrot())  # Meow!

# No need to check types — just call the method.

