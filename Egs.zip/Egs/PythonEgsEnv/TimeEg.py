import time
# 1. Get Current Timestamp (Epoch Time)
print(time.time())  # Seconds since Jan 1, 1970 Output: 1750494548.5767655
# 2. Convert Timestamp to Readable String
print(time.ctime())              # Current time in readable format : Sat Jun 21 13:59:08 2025
print(time.ctime(1729362859))   # Convert specific timestamp : Sun Oct 20 00:04:19 2024
# 3. Pause Execution
print("Start..wait for 2 seconds..") # Start..wait for 2 seconds..
time.sleep(2)  # Wait for 2 seconds
print("Wait Ends") # Wait Ends
# 4. Get Local Time Components
t = time.localtime()
print(t) # time.struct_time(tm_year=2025, tm_mon=6, tm_mday=21, tm_hour=13, tm_min=59, tm_sec=10, tm_wday=5, tm_yday=172, tm_isdst=0)
print("Hour:", t.tm_hour, "Year:", t.tm_year) # Hour: 13 Year: 2025
# 5. Format Time Using strftime()
formatted = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
print("Formatted:", formatted) # Formatted: 2025-06-21 13:59:10
# 6. Parse Time from String with strptime()
time_obj = time.strptime("2025-06-19", "%Y-%m-%d") 
print(time_obj) # time.struct_time(tm_year=2025, tm_mon=6, tm_mday=19, tm_hour=0, tm_min=0, tm_sec=0, tm_wday=3, tm_yday=170, tm_isdst=-1)
# 7. Get GMT/UTC Time
print(time.gmtime())  # Returns struct_time in UTC
# time.struct_time(tm_year=2025, tm_mon=6, tm_mday=21, tm_hour=8, tm_min=29, tm_sec=10, tm_wday=5, tm_yday=172, tm_isdst=0)
# 8. Performance Measurement
start = time.time()
for i in range(1000000):
    pass
end = time.time()
print("Time taken:", end - start) # Time taken: 0.06343245506286621

