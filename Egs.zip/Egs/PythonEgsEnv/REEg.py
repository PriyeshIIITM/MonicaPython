import re
# 1. Simple Pattern Match
text = "hello world"
match = re.match("hello", text) 
print(match.group()) if match else print("No match")  # hello
# 2. Search for a Pattern Anywhere
text = "The number is 42"
result = re.search(r"\d+", text) # The r in r"\d+" stands for a raw string literal : \ as-is
print(result.group())  # Output: 42
# 3. Find All Matches
text = "Item1: 25, Item2: 30, Item3: 45"
numbers = re.findall(r"\d+", text)
print(numbers)  # ['1', '25', '2', '30', '3', '45']
# 4. Find with Iterator
for match in re.finditer(r"\d+", "123 apples and 456 oranges"):
    print("Found", match.group(), "at", match.span()) # Found 123 at (0, 3) # Found 456 at (15, 18)
# 5. Substitute Pattern
text = "My number is 123-456-7890"
updated = re.sub(r"\d", "*", text)
print(updated)  # My number is ***-***-****
# 6. Split on Pattern
line = "apple, banana; cherry orange"
parts = re.split(r"[,; ]+", line)
print(parts)  # ['apple', 'banana', 'cherry', 'orange']
# 7. Compile Pattern for Reuse
pattern = re.compile(r"\d+")
print(pattern.findall("12 eggs, 30 bananas"))  # ['12', '30']
# Example: Email Matcher
email = "test.user@example.com"
if re.match(r"[^@]+@[^@]+\.[^@]+", email):
    print("Valid email")   # Valid email
else:
    print("Invalid email")
