import psutil
# 1. CPU Information
print("CPU Count:", psutil.cpu_count())                  # Logical CPUs # CPU Count: 2
print("CPU Usage:", psutil.cpu_percent(interval=1), "%") # CPU usage % # CPU Usage: 1.6 %
print("Per Core Usage:", psutil.cpu_percent(percpu=True)) # Per Core Usage: [2.9, 1.5]
# 2. Memory Information
mem = psutil.virtual_memory()
print(f"Total: {mem.total / (1024 ** 3):.2f} GB") # Total: 4.00 GB
print(f"Used: {mem.used / (1024 ** 3):.2f} GB") # Used: 2.44 GB
print(f"Available: {mem.available / (1024 ** 3):.2f} GB") # Available: 1.56 GB
# 3. Disk Usage
disk = psutil.disk_usage('/')
print(f"Disk Total: {disk.total / (1024 ** 3):.2f} GB") # Disk Total: 59.68 GB
print(f"Used: {disk.used / (1024 ** 3):.2f} GB") # Used: 23.32 GB
print(f"Free: {disk.free / (1024 ** 3):.2f} GB") # Free: 36.36 GB
# 4. Network Info
net_io = psutil.net_io_counters()
print(f"Bytes Sent: {net_io.bytes_sent}")  # Bytes Sent: 26371089
print(f"Bytes Received: {net_io.bytes_recv}")  # Bytes Received: 1795272911
# 5. List Running Processes
for proc in psutil.process_iter(['pid', 'name']):
    print(proc.info)  # {'pid': 5678, 'name': 'python.exe'}  {'pid': 0, 'name': 'System Idle Process'} ..
# 6. Details of a Specific Process : # Get the first real process on the system
for proc in psutil.process_iter(['pid', 'name', 'status', 'memory_info']):
    try:
        print("PID:", proc.info['pid'], "Name:", proc.info['name'])  # PID: 0 Name: System Idle Process
        # Status: running Memory Info: pmem(rss=8192, vms=61440, num_page_faults=9, peak_wset=12288,
        # wset=8192, peak_paged_pool=0, paged_pool=0, peak_nonpaged_pool=272, nonpaged_pool=272,
        # pagefile=61440, peak_pagefile=61440, private=61440)
        print("Status:", proc.info['status'], "Memory Info:", proc.info['memory_info'])
        break  # Exit after the first one
    except (psutil.NoSuchProcess, psutil.AccessDenied):
        continue
# 7. Battery Status (on laptops)
battery = psutil.sensors_battery()
if battery:
    print("Battery %:", battery.percent, "Plugged in:", battery.power_plugged)
else:
    print("No battery info available") # No battery info available

