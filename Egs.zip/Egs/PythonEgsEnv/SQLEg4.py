import pandas as pd
import pyodbc

import warnings
warnings.filterwarnings("ignore") 

# --- Connect to SQL Server ---
conn = pyodbc.connect(
    'DRIVER={ODBC Driver 18 for SQL Server};'
    'SERVER=localhost;DATABASE=pythondb;Trusted_Connection=yes;TrustServerCertificate=yes;'
)

# --- Load Data from SQL Table ---
query = "SELECT branch, COUNT(*) as total_employees, AVG(salary) as avg_salary FROM emptbl GROUP BY branch"
df = pd.read_sql(query, conn)

# --- Save to Excel and Add Charts ---
output_file = 'Employee_Report_with_Charts.xlsx'
with pd.ExcelWriter(output_file, engine='xlsxwriter') as writer:
    df.to_excel(writer, sheet_name='Report', index=False)
    
    workbook = writer.book
    worksheet = writer.sheets['Report']

    # --- Column Chart (Bar) ---
    chart_col = workbook.add_chart({'type': 'column'})
    chart_col.add_series({
        'name':       'Employee Count',
        'categories': ['Report', 1, 0, len(df), 0],  # branch names
        'values':     ['Report', 1, 1, len(df), 1],  # total_employees
    })
    chart_col.set_title({'name': 'Employee Count per Branch'})
    worksheet.insert_chart('F2', chart_col)

    # --- Pie Chart ---
    chart_pie = workbook.add_chart({'type': 'pie'})
    chart_pie.add_series({
        'name':       'Employee Distribution',
        'categories': ['Report', 1, 0, len(df), 0],
        'values':     ['Report', 1, 1, len(df), 1],
    })
    chart_pie.set_title({'name': 'Branch Distribution (Pie)'})
    worksheet.insert_chart('F18', chart_pie)

    # --- Line Chart (Average Salary Trend) ---
    chart_line = workbook.add_chart({'type': 'line'})
    chart_line.add_series({
        'name':       'Average Salary',
        'categories': ['Report', 1, 0, len(df), 0],
        'values':     ['Report', 1, 2, len(df), 2],
    })
    chart_line.set_title({'name': 'Average Salary per Branch'})
    worksheet.insert_chart('F34', chart_line)

print(f"Excel file '{output_file}' created with Column, Pie, and Line charts.")
# Excel file 'Employee_Report_with_Charts.xlsx' created with Column, Pie, and Line charts.

