print(" 1. Create a Set of Squares")
squares = {x**2 for x in range(5)}
print(squares)  # Output: {0, 1, 4, 9, 16}
print("2. Remove Duplicates")
words = ["apple", "banana", "apple", "orange"]
unique_lengths = {len(word) for word in words}
print(unique_lengths)  # Output: {5, 6}
print("3. With Condition (Even Numbers Only)")
evens = {x for x in range(10) if x % 2 == 0}
print(evens)  # Output: {0, 2, 4, 6, 8}
print(" 4. Using Strings (Unique Letters)")
text = "hello world"
letters = {char for char in text if char != ' '}
print(letters)  # Output: unique characters, e.g. {'h', 'e', 'l', 'o', 'w', 'r', 'd'}
print(" 5. Nested Set Comprehension (Cartesian Product)")
result = {(x, y) for x in range(2) for y in range(2)}
print(result)  # Output: {(0, 0), (0, 1), (1, 0), (1, 1)}
print(" Comparison: Set vs List Comprehension")
print(" List allows duplicates")
print([x % 3 for x in range(6)])  # [0, 1, 2, 0, 1, 2]
print(" Set removes duplicates")
print({x % 3 for x in range(6)})  # {0, 1, 2}

