class Animal:  # base class
    def speak(self):  
        print("Animal Speaking")
    def move(self):
        print("Animal moves(walk/fly/swim..)")

class LivingBeing:
    def breathe(self):
        print("Living Beings breathe")
    def move(self):
        print("Living Beings moves(walk/fly/swim..)")

#child class Dog, Human inherits the base class Animal  

class Dog(LivingBeing, Animal):  #multiple inheritance
    def bark(self):  
        print("dog barking")
    def move(self):             #overriding
        super().move()
        print("Dog moves(walk)")
        
class Human(Animal):      #single Inheritance
    def think(self):  
        print("thinking")



d = Dog()  
d.bark()  
d.speak()
d.move()
d.breathe()

j = Human()
#j.bark() # error
j.think()
j.speak()
j.move()
#j.breathe()

print(Dog.__bases__)

print(issubclass(Dog, Animal))
print(issubclass(Dog, Human))


print(isinstance(d, Dog))
print(isinstance(d, Animal))



