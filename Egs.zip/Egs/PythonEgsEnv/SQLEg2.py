import pyodbc

# ---------- Connect to SQL Server ----------
conn = pyodbc.connect(
    'DRIVER={ODBC Driver 18 for SQL Server};'
    'SERVER=localhost;'
    'DATABASE=pythondb;'
    'Trusted_Connection=yes;'
    'TrustServerCertificate=yes;'
)
cursor = conn.cursor()

print("Connected to SQL Server - pythondb")

# ---------- CRUD Functions ----------
def create_record():
    try:
        empid = int(input("Enter Employee ID: "))
        name = input("Enter Employee Name: ")
        salary = float(input("Enter Salary: "))
        designation = input("Enter Designation: ")
        branch = input("Enter Branch: ")
        cursor.execute
        ("INSERT INTO emptbl (empid, empname, salary, designation, branch) VALUES (?, ?, ?, ?, ?)",
                       (empid, name, salary, designation, branch))
        conn.commit()
        print("Record inserted successfully.\n")
    except Exception as e:
        print("Error:", e)

def read_records():
    cursor.execute("SELECT * FROM emptbl")
    rows = cursor.fetchall()
    if rows:
        print("\n All Employees:")
        for row in rows:
            print(f"ID: {row.empid}, Name: {row.empname}, Salary: {row.salary}, Designation: {row.designation}, Branch: {row.branch}")
    else:
        print("No records found.\n")

def update_record():
    try:
        empid = int(input("Enter Employee ID to update: "))
        new_salary = float(input("Enter new Salary: "))
        cursor.execute("UPDATE emptbl SET salary = ? WHERE empid = ?", (new_salary, empid))
        conn.commit()
        print("Record updated.\n")
    except Exception as e:
        print("Error:", e)

def delete_record():
    try:
        empid = int(input("Enter Employee ID to delete: "))
        cursor.execute("DELETE FROM emptbl WHERE empid = ?", (empid,))
        conn.commit()
        print("Record deleted.\n")
    except Exception as e:
        print("!!!Error: ", e)

# ---------- Menu ----------
def menu():
    while True:
        print("\n====== EMPLOYEE DATABASE MENU ======")
        print("1. Insert New Employee")
        print("2. View All Employees")
        print("3. Update Employee Salary")
        print("4. Delete Employee")
        print("5. Exit")

        choice = input("Enter your choice (1-5): ")

        if choice == '1':
            create_record()
        elif choice == '2':
            read_records()
        elif choice == '3':
            update_record()
        elif choice == '4':
            delete_record()
        elif choice == '5':
            print("Exiting program.")
            break
        else:
            print("!!Invalid choice. Please enter a number from 1 to 5.!!")

# Run the menu
menu()

# Close connection
cursor.close()
conn.close()

