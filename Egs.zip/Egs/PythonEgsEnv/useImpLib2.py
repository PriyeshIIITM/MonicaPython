from impLib import  x 

#x=40
print("x:",x)
