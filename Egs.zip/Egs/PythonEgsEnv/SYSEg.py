import sys
# 1. Command-Line Arguments with sys.argv
print("Script name:", sys.argv[0])
print("Arguments:", sys.argv[1:])
# Script name: C:/Users/monica/Desktop/myenv/myenv/Scripts/MonicaEgs/aaa.py
# Arguments: ['hello', 'world']

# 2. Exit a Program Gracefully
# sys.exit("Exiting program due to an error")
# SystemExit: Exiting program due to an error

# 3. Module Search Path (sys.path)
for p in sys.path:
    print(p)
# Shows where Python looks for modules.

# 4. Python Version and Info
print(sys.version)        # Python version string
# 3.13.5 (tags/v3.13.5:6cb20a2, Jun 11 2025, 16:15:46) [MSC v.1943 64 bit (AMD64)]
print(sys.version_info)   # Tuple with major, minor, micro
# sys.version_info(major=3, minor=13, micro=5, releaselevel='final', serial=0)
# 5. Redirect Output
sys.stdout.write("Hello, redirected stdout!\n")
# Hello, redirected stdout!
# 6. Size of an Object in Bytes
x = [1, 2, 3]
print(sys.getsizeof(x))  # Memory size in bytes : 88
