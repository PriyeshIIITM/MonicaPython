import pandas as pd

# Step 1: Create two DataFrames
data1 = {
    "Employee_ID": [101, 102, 103, 104],
    "Name": ["Alice", "Bob", "Charlie", "David"],
    "Department": ["HR", "Finance", "IT", "HR"],
}

data2 = {
    "Employee_ID": [101, 102, 105, 106],
    "Salary": [60000, 70000, 80000, 75000],
}

df1 = pd.DataFrame(data1)
df2 = pd.DataFrame(data2)

print("DataFrame 1 (Employee Info):")
print(df1)
print("\nDataFrame 2 (Salary Info):")
print(df2)

# Step 2: GroupBy - Count employees by department
department_counts = df1.groupby("Department")["Employee_ID"].count()
print("\nEmployee count by department:")
print(department_counts)

# Step 3: Merging - Merge the two DataFrames based on Employee_ID
merged_df = pd.merge(df1, df2, on="Employee_ID", how="inner")
print("\nMerged DataFrame (Employee info with salary):")
print(merged_df)

# Step 4: Joining - Join two DataFrames based on index
# For this to work, we set an index
df1.set_index("Employee_ID", inplace=True)
df2.set_index("Employee_ID", inplace=True)

joined_df = df1.join(df2, how="left")
print("\nJoined DataFrame (Employee info with salary):")
print(joined_df)

