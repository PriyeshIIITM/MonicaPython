import pandas as pd
# Step 1: Create a simple DataFrame
data = {
    "Name": ["Alice", "Bob", "Charlie"],
    "Age": [25, 30, 35],
    "City": ["New York", "Los Angeles", "Chicago"]
}
df = pd.DataFrame(data)
print("Original DataFrame:\n", df)
# Step 2: Export the DataFrame to a CSV file
csv_file = "example.csv"
df.to_csv(csv_file, index=False)  # Save without the index
print(f"\nDataFrame exported to {csv_file}")
# Step 3: Export the DataFrame to an Excel file
excel_file = "example.xlsx"
df.to_excel(excel_file, index=False, sheet_name="Sheet1")
print(f"DataFrame exported to {excel_file}")
# Step 4: Import the CSV file back into a DataFrame
df_csv = pd.read_csv(csv_file)
print("\nDataFrame imported from CSV:\n", df_csv)
# Step 5: Import the Excel file back into a DataFrame
df_excel = pd.read_excel(excel_file, sheet_name="Sheet1")
print("\nDataFrame imported from Excel:\n", df_excel)
