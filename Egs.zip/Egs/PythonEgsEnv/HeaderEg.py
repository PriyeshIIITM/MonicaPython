import requests

r = requests.get("https://httpbin.org/headers")
print("Request Headers Sent:")
print(r.request.headers)

print("\nResponse Headers Received:")
print(r.headers)

# Request Headers Sent:
# {'User-Agent': 'python-requests/2.32.4', 'Accept-Encoding': 'gzip, deflate', 'Accept': '*/*', 'Connection': 'keep-alive'}

# Response Headers Received:
# {'Date': 'Sat, 21 Jun 2025 20:10:09 GMT', 'Content-Type': 'application/json', 'Content-Length': '225', 'Connection': 'keep-alive', 'Server': 'gunicorn/19.9.0', 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Credentials': 'true'}

