import win32com.client as win32

# Start Excel (in background)
excel = win32.gencache.EnsureDispatch('Excel.Application')

# Show Excel window (False = hidden)
excel.Visible = True

# Create a new workbook
wb = excel.Workbooks.Add()

# Select the first sheet
sheet = wb.Sheets(1)
sheet.Name = "Employees"

# Write data
sheet.Cells(1, 1).Value = "Name"
sheet.Cells(1, 2).Value = "Salary"
sheet.Cells(2, 1).Value = "Alice"
sheet.Cells(2, 2).Value = 70000
sheet.Cells(3, 1).Value = "Bob"
sheet.Cells(3, 2).Value = 80000

# Save the workbook
wb.SaveAs(r"C:\Users\monica\Desktop\employee_dataWin32.xlsx")

# Optional: Close Excel
excel.Application.Quit()
