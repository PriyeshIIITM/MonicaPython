from impLib import *

#x=40
print("x:",x)
print("y:",y)
