import calendar
# 1. Print a Month Calendar
print(calendar.month(2025, 6))
# 2. Print a Full Year Calendar
print(calendar.calendar(2025))
# 3. Check Leap Year
print(calendar.isleap(2024))  # True
print(calendar.isleap(2025))  # False
# 4. Get Weekday of a Date # Returns 0 (Monday) to 6 (Sunday)
print(calendar.weekday(2025, 6, 19))  # e.g., Thursday → 3
# 5. Set First Day of the Week
calendar.setfirstweekday(calendar.SUNDAY)
print(calendar.month(2025, 6))
# 6. Get Month as a Matrix # Output: Each inner list represents a week; 0 means empty day.
matrix = calendar.monthcalendar(2025, 6)
for week in matrix:
    print(week)
# 7. Get Day Name or Abbreviation
print(calendar.day_name[0])   # Monday
print(calendar.day_abbr[2])  # Wed
# 8. Get Month Name or Abbreviation
print(calendar.month_name[6])   # June
print(calendar.month_abbr[12]) # Dec
# 9. Count Leap Years in Range
print(calendar.leapdays(2000, 2025))  # Leap years from 2000 to 2024 # 7
