class Employee:    
    id=10   
    name="John Doe"    
    def display (self):    
        print("ID: %d \nName: %s"%(self.id,self.name))    

# Creating a emp instance of Employee class  
emp=Employee()
print("default emp object")
emp.display()
emp.id=20
emp.name="Jane Smith"
print("emp object's values changed")
emp.display()
