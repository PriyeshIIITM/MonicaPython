import glob
# 1. List All .txt Files in a Folder
files = glob.glob("*.txt")
print(files)  # ['file_a.txt', 'file_b.txt', 'new.txt']
# 2. Match Files by Prefix or Suffix
print(glob.glob("data*.csv"))  # Matches data_2021.csv, data_june.csv # ['data.csv']
print(glob.glob("*.log"))       # Matches all .log files # ['my_log.log']
# 3. Match All Files in a Subdirectory
print(glob.glob("folder1/*.txt"))  # ['folder1\\a.txt', 'folder1\\b.txt', 'folder1\\c.txt']
# 4. Recursive Match — All .py Files in Subfolders
files = glob.glob("**/*.py", recursive=True)  # **/ is used to match all subdirectories recursively.
print(files) # ['aaa.py', 'MenuFiles.py', 'ReadCSV.py', 'Write2CSV.py']
# 5. Using ? Wildcard for Single Character Match
print(glob.glob("file?.txt"))  # Matches file1.txt, file2.txt but not file10.txt # []
# 6. Using in Loops for Batch Processing
for filename in glob.glob("*.csv"):
    print("Processing:", filename)
# Processing: data.csv # Processing: output.csv # Processing: output_dict.csv

