import pandas as pd

# Sample DataFrame
data = {
    "Name": ["Alice", "Bob", "Charlie", "David", "Eva", "Frank"],
    "Age": [24, 30, 35, 28, 22, None],
    "City": ["Delhi", "Mumbai", "Chennai", "Delhi", "Pune", "Delhi"],
    "Gender": ["Female", "Male", "Male", "Male", "Female", "Male"],
    "Score": [88, 92, 70, 75, 90, None],
    "Email": ["alice@gmail.com", "bob@yahoo.com", "charlie@outlook.com", 
              "david@gmail.com", "eva@gmail.com", None]
}
df = pd.DataFrame(data)
print("Original DataFrame:\n", df, "\n")
# 1. Filter Rows with Age > 25
print("Age > 25:\n", df[df["Age"] > 25], "\n")
# 2. Filter by Multiple Conditions (Age > 25 and City == 'Delhi')
print("Age > 25 and City == 'Delhi':\n", df[(df["Age"] > 25) & (df["City"] == "Delhi")], "\n")
# 3. Using query()
print("Using query() - Age > 25 and Gender == 'Male':\n",
      df.query("Age > 25 and Gender == 'Male'"), "\n")
# 4. Using .loc[] to Select Filtered Rows and Columns
print("Select rows where Score > 80 and only Name + Score columns:\n",
      df.loc[df["Score"] > 80, ["Name", "Score"]], "\n")
# 5. Using .between()
print("Age between 25 and 35:\n", df[df["Age"].between(25, 35)], "\n")
# 6. Using .str Methods
print("Names starting with 'A':\n",
      df[df["Name"].str.startswith("A")], "\n")
print("Emails from Gmail:\n",
      df[df["Email"].str.contains("@gmail.com", na=False)], "\n")
# 7. Using .isin()
print("City in ['Delhi', 'Mumbai']:\n",
      df[df["City"].isin(["Delhi", "Mumbai"])], "\n")
# 8. Filter Rows with Missing or Non-missing Age
print("Rows with Age NOT NULL:\n", df[df["Age"].notna()], "\n")
print("Rows with Age NULL:\n", df[df["Age"].isna()], "\n")
# 9. Filtering by Columns Using .filter()
# axis=1 to apply filtering to columns (use axis=0 for rows)
# Regex Pattern	1) ^S : Starts with S 2) e$ : Ends with e 3) .*a.* : Contains a (. ->single char, *->0 or more)
# 4) ^.{5}$ : Exactly 5 characters long 5) [aeiou] : Any vowel 6) [a-zA-Z] : Any Alphabet
print("Filter columns starting with 'S':\n",
      df.filter(regex="^S", axis=1), "\n")
# 10. Custom Function with .apply()
print("Custom Filter (Score is even number):\n",
      df[df["Score"].apply(lambda x: x % 2 == 0 if pd.notna(x) else False)], "\n")
