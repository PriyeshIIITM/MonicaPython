import logging
# Basic Example
logging.basicConfig(level=logging.INFO)  
logging.info("This is an info message")  # INFO:root:This is an info message
logging.warning("This is a warning") # WARNING:root:This is a warning
logging.error("This is an error")  # ERROR:root:This is an error
# Custom Log Format
logging.basicConfig( level=logging.DEBUG, format='%(asctime)s - %(levelname)s - %(message)s')
logging.debug("Debugging info")
logging.info("Info message") # INFO:root:Info message
# Logging to a File
logging.basicConfig( filename='app.log', level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s' )
logging.info("This will go to a file") # INFO:root:This will go to a file
# Logging with Exception Info
try:
    1 / 0
except ZeroDivisionError:
    logging.exception("Exception occurred")  # Includes traceback automatically. ERROR:root:Exception occurred
    # Traceback (most recent call last): File "C:/Users/monica/Desktop/myenv/myenv/Scripts/MonicaEgs/aaa.py", line 16, in <module>
    # 1 / 0   ~~^~~  ZeroDivisionError: division by zero
# Creating and Using Custom Loggers
logger = logging.getLogger("my_logger")
logger.setLevel(logging.DEBUG)
handler = logging.FileHandler("my_log.log")
formatter = logging.Formatter('%(name)s - %(levelname)s - %(message)s')
handler.setFormatter(formatter)
logger.addHandler(handler)
logger.info("This is from custom logger") # INFO:my_logger:This is from custom logger
