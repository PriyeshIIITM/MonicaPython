#Reading a JSON File
import json

with open('data.json', 'r') as file:
    data = json.load(file)
    print(data)

# Writing to a JSON File
# import json

person = {'name': 'Alice', 'age': 30}
with open('output.json', 'w') as file:
    json.dump(person, file, indent=2)
