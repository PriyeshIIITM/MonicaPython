import requests
# JSON API Fetch
url = "https://jsonplaceholder.typicode.com/users"
users = requests.get(url).json()
for user in users:
    print(user["name"], "-", user["email"])
# Handling Errors Gracefully
try:
    r = requests.get("https://badurl.example.com")
    r.raise_for_status()  # Raises HTTPError if not 200 OK
except requests.exceptions.RequestException as e:
    print("\nError:", e)
# Sending JSON in a POST Request
payload = {"title": "foo", "body": "bar", "userId": 1}
r = requests.post("https://jsonplaceholder.typicode.com/posts", json=payload)
print("\nSending JSON in Post request: \n", r.json())
# Working with Query Parameters
myparams = {"search": "python", "page": 2}
r = requests.get("https://httpbin.org/get", params=myparams)
print("\nSending Query parameters in Get request: \n", r.json())
