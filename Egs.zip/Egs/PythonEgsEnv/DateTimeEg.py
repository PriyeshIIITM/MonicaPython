# Importing datetime
import datetime
# 1. Current Date and Time
print("Now:", datetime.datetime.now())  # Now: 2025-06-21 13:44:34.645493
# 2. Current Date
print("Today:", datetime.date.today())  # Today: 2025-06-21
# 3. Creating a Specific Date or Time
print(datetime.date(2025, 1, 16))  # 2025-01-16
print(datetime.time(14, 30, 0))  # 14:30:00
# 4. Formatting Dates (strftime)
now = datetime.datetime.now()
print(now.strftime("%Y-%m-%d %H:%M:%S"))  # 2025-06-18 23:48:30
print(now.strftime("%A, %B %d"))          # Wednesday, June 18
#  5. Parsing Strings into Dates (strptime)
dt = datetime.datetime.strptime("2025-06-18", "%Y-%m-%d")
print(dt)  # 2025-06-18 00:00:00
# 6. Date Arithmetic with timedelta
from datetime import timedelta
today = datetime.date.today()
next_week = today + timedelta(days=7)
yesterday = today - timedelta(days=1)
print("Next week:", next_week) # Next week: 2025-06-28
print("Yesterday:", yesterday) # Yesterday: 2025-06-20
# 7. Get Difference Between Two Dates
delta = datetime.date(2025, 6, 18) - datetime.date(2025, 6, 10)
print(delta.days)  # 8
# 8. Working with Time Only
t = datetime.time(12, 45, 30)
print(t.hour, ":", t.minute) # 12 : 45   
# 9. Getting Current UTC Time
utc_now = datetime.datetime.now(datetime.UTC) # datetime.datetime.utcnow()
print("UTC Now:", utc_now) # UTC Now: 2025-06-21 08:14:34.835383+00:00
