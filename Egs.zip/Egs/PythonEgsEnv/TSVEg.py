import csv

# Reading TSV
with open('data.tsv', mode='r') as file:
    reader = csv.reader(file, delimiter='\t')
    for row in reader:
        print(row)

# Writing TSV
data = [['Name', 'Age'], ['Alice', 30]]

with open('output.tsv', mode='w', newline='') as file:
    writer = csv.writer(file, delimiter='\t')
    writer.writerows(data)

