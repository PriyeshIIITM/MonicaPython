class Employee:
   'Common base class for all employees'
   empCount = 0
   insVar = 0

   def __init__(self, name, salary):
      self.name = name
      self.salary = salary
      Employee.empCount += 1
      self.insVar +=1
   
   def displayCount(self):
     print ("Total Employee %d" % Employee.empCount)
     print("Instance Variable is ", self.insVar)

   def display(self):
      print ("\n\nName : ", self.name,  ", Salary: ", self.salary,
             "\nInstance Count with class Var", Employee.empCount,
             "Instance count with instance var:",self.insVar)



print("emp1:")
em1=Employee("John",1000)

em1.display()
em1.displayCount()


print("emp2:")
em1=Employee("Jane",5000)

em1.display()
em1.displayCount()
