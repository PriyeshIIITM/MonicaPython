class Student:
        # Constructor – parameterized
        def setName(self, name):
              print("This is setter of name")
              self.name = name
        def __init__(self):
              print("This is default constructor")
              self.name = "John Doe"
        def __init__(self):
              print("This is default constructor re-written")
              self.name = "Jane Doe"
        def show(self):
              print("Hello",self.name)
        def show(self):
              print("Hello show again: ",self.name)



student1 = Student()
student1.setName("John")
student1.show()
student = Student()
student.show()
