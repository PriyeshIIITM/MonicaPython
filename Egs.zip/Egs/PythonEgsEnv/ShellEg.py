import subprocess
import os
# 1. Run a Simple Command (cross-platform safe) # If you run your script via: cmd / Terminal ➝ subprocess.run(..., shell=True) will display output
subprocess.run("echo Hello from subprocess", shell=True)
# 2. Run and Capture Output : In IDLE 
result = subprocess.run("echo Hello", shell=True, capture_output=True,
                        text=True)
print(result.stdout)
# 3. Check for Errors (Non-Existing File with `dir`)
result = subprocess.run("dir non_existing_file", shell=True,
                        capture_output=True, text=True)
print("Return Code:", result.returncode);
print("Error:", result.stderr) # Return Code: 1 # Error: File Not Found
# 4. Raise Exception on Error
try:
    subprocess.run("dir non_existing", shell=True, check=True)
except subprocess.CalledProcessError as e:
    print("Caught Error:", e) # Caught Error: Command 'dir non_existing' returned non-zero exit status 1.
# 5. Run OS Command with condition : dir command runs here
print(subprocess.run("dir" if os.name == "nt" else "ls -l", shell=True, capture_output=True, text=True).stdout)
# 6. Piping Between Commands (works on Unix, limited on Windows): echo hello world | grep hello
p1 = subprocess.Popen("echo hello world", shell=True, stdout=subprocess.PIPE) # Run `echo hello world` and capture its output
# Pipe the output of p1 into `findstr hello` (Windows alternative of `grep`)
p2 = subprocess.Popen("findstr hello", shell=True, stdin=p1.stdout, stdout=subprocess.PIPE)
output = p2.communicate()[0] # Get the final output
print(output.decode()) # Decode from bytes to string and print: # hello world
# 7. Installing Packages (works)
# subprocess.run(["pip", "install", "requests"])  # Uncomment to use
# 8. Pass Input to a Python Command
result = subprocess.run(["python", "-c", 'print("Hi")'], capture_output=True, text=True)
print(result.stdout) # Hi

