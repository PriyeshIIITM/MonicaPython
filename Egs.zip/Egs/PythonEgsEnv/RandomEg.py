import random
# 1. Generate a Random Float Between 0 and 1
print(random.random())  # Example: 0.32474791815685133
# 2. Generate a Random Integer
print(random.randint(1, 10))  # Includes both 1 and 10 # 1
# 3. Random Float in a Given Range
print(random.uniform(1.5, 5.5))  # Includes decimals # 1.9714224530050317
# 4. Random Element from a List
colors = ['red', 'blue', 'green']  # red
print(random.choice(colors))  # Random color
# 5. Shuffle a List In-Place
deck = [1, 2, 3, 4, 5]
random.shuffle(deck) # [4, 1, 5, 2, 3]
print(deck)
# 6. Pick Multiple Unique Random Elements
lottery_numbers = random.sample(range(1, 50), 6)
print(lottery_numbers) # [27, 44, 34, 11, 18, 38]
# 7. Generate Random Number from a Range with a Step
print(random.randrange(0, 100, 5))  # e.g., 0, 5, 10, ..., 95  # 5
# 8. Set a Seed (for Reproducibility)
random.seed(42)  # 82
print(random.randint(1, 100))  # Will always return the same number with the same seed
# 9. Generate Numbers from a Distribution
print(random.gauss(mu=0, sigma=1))  # Normal distribution # 1.2587003164876114
# Other options: random.betavariate(alpha, beta), random.expovariate(lambd), random.normalvariate(mu, sigma), random.triangular(low, high, mode), random.weibullvariate(alpha, beta)

