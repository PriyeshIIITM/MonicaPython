#program to map the list and get its square    
lst = [10,20,30,40,50,60]

square_list = list(map(lambda x:x**2,lst)) 

# the tuple contains all the items of the list for which the lambda function returns another list with square of each element of the list    

print(square_list)    

#Output:
#[100, 400, 900, 1600, 2500, 3600]



