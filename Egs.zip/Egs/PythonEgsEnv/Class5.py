class Student:  
    def __init__(self, name, id, age):  
        self.name = name  
        self.id = id  
        self.age = age  
     
# creates the object of the class Student
print("Student Object : name=John, id=101, age=22") 
s = Student("John", 101, 22)  
  
# prints the attribute name of the object s  
print("getattr(s, 'name'):",getattr(s, 'name') )
  
# reset the value of attribute age to 23  
setattr(s, "age", 23)  
  
# prints the modified value of age  
print("setattr(s, 'age', 23) : makes age as: ", getattr(s, 'age'))  
  
# prints true if the student contains the attribute with name id  
  
print("hasattr(s, 'id'):",hasattr(s, 'id'))  
# deletes the attribute age  
delattr(s, 'age')
print("delattr(s, 'age')")

print("hasattr(s, 'age'):",hasattr(s, 'age')) 
# this will give an error since the attribute age has been deleted  
#print(s.age)  
