# Importing the Module
import os
# 1. File and Directory Operations
print(os.getcwd())             # Get current working directory
os.chdir('../PythonEgs')        # Change working directory
print(os.listdir())            # List files and folders in current dir
os.mkdir('test_folder')
os.mkdir('folder')           # Make a single directory
os.makedirs('a/b/c')           # Make nested directories
os.remove('file.txt')          # Remove a file
os.rmdir('test_folder')        # Remove an empty folder
os.rename('old.txt', 'new.txt')# Rename a file or folder
# 2. Path Handling (os.path)
print(os.path.join("folder", "file.txt"))    # Combine paths
print(os.path.exists("file.txt"))            # Check if file exists
print(os.path.isfile("file.txt"))            # Is it a file?
print(os.path.isdir("folder"))               # Is it a directory?
print(os.path.abspath("file.txt"))           # Absolute path
print(os.path.basename("/a/b/file.txt"))     # file.txt
print(os.path.dirname("/a/b/file.txt"))      # /a/b
# 3. Environment Variables
print(os.environ)                        # Get all env variables
print(os.environ.get("PATH"))           # Get specific env var
os.environ["MY_VAR"] = "123"            # Set env var (runtime only)
# 4. Executing System Commands
os.system("echo Hello")   # Run shell command
# For better control and output capture, use subprocess instead.
# 5. Walking Through Directories
for dirpath, dirnames, filenames in os.walk("."):
    print("Directory:", dirpath)
    print("Subdirectories:", dirnames)
    print("Files:", filenames)
# Example: Create and List a Folder
folder = "my_folder"
if not os.path.exists(folder):
    os.mkdir(folder)
print("Files in folder:", os.listdir(folder))

