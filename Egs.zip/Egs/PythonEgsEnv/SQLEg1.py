import pyodbc

# Define connection string :
# For SA Authentication : 
##conn = pyodbc.connect(
##    'DRIVER={ODBC Driver 18 for SQL Server};'
##    'SERVER=localhost;'
##    'DATABASE=pythondb;'
##    'UID=your_username;'
##    'PWD=your_password;'
##    'TrustServerCertificate=yes;'
##)
# For Windows Authentication : 
conn = pyodbc.connect(
    'DRIVER={ODBC Driver 18 for SQL Server};'
    'SERVER=localhost;'
    'DATABASE=pythondb;'
    'Trusted_Connection=yes;'
    'TrustServerCertificate=yes;'
)

# Create a cursor
cursor = conn.cursor()
print("Connection successful!")   # Connection successful!
