import pandas as pd

# Sample data
data = {
    'Department': ['IT', 'HR', 'Finance', 'Sales'],
    'Employees': [20, 12, 15, 18]
}
df = pd.DataFrame(data)

# Create Excel writer using xlsxwriter
with pd.ExcelWriter('chart_example.xlsx', engine='xlsxwriter') as writer:
    df.to_excel(writer, sheet_name='Sheet1', index=False)
    
    workbook = writer.book
    worksheet = writer.sheets['Sheet1']

    # Create a chart object
    chart = workbook.add_chart({'type': 'column'})

    # Configure the chart (skip header row)
    chart.add_series({
        'name':       'Employees per Dept',
        'categories': ['Sheet1', 1, 0, 4, 0],  # Dept names
        'values':     ['Sheet1', 1, 1, 4, 1],  # Employee counts
    })

    # Add chart title and axes
    chart.set_title({'name': 'Employee Count by Department'})
    chart.set_x_axis({'name': 'Department'})
    chart.set_y_axis({'name': 'No. of Employees'})

    # Insert the chart into worksheet
    worksheet.insert_chart('E2', chart)

print("Excel with chart created as 'chart_example.xlsx'")
# Excel with chart created as 'chart_example.xlsx'


