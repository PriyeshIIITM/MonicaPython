import copy
original = {
    "age": 28,
    "skills": ["Python", "ML"]
}
print(f"\nOriginal dictionary:\n{original}")

shallow_copy = original.copy()
print(f"\nShallow copy dictionary:\n{shallow_copy}")
# Modify outer value
shallow_copy["age"] = 30
print("\npost shallow_copy[age] = 30:")
print(f"\nOriginal dictionary:\n{original}")
print(f"\nShallow copy dictionary:\n{shallow_copy}")

# Modify nested list
shallow_copy["skills"].append("Data Science")
print("\npost shallow_copy[skills].append(Data Science):")
print("\nOriginal:", original)
print("\nShallow Copy:", shallow_copy)


deep_copy = copy.deepcopy(original)
print(f"\ndeep copy dictionary:\n{deep_copy}")
# Modify nested dictionary

# Modify nested list
deep_copy["skills"].append("NodeJS")
print("\npost deep_copy[skills].append(NodeJS):")
print("\nOriginal:", original)
print("\ndeep Copy:", deep_copy)
