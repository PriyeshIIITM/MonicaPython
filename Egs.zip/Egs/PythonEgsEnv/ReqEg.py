# Sending HTTP Requests
import requests
# a. GET Request
response = requests.get("https://jsonplaceholder.typicode.com/posts/1")
print("Getting data from https://jsonplaceholder.typicode.com/posts/1 : \n")
print(response.status_code)
print(response.text)  # or response.json()
# b. POST Request with Data
response = requests.post("https://httpbin.org/post", data={"name": "Alice"})
print("\nPosting data={name: Alice} to https://httpbin.org/post : \n")
print(response.json())
# c. Passing Headers
myheaders = {"User-Agent": "my-python-script"}
r = requests.get("https://httpbin.org/headers", headers=myheaders)
print("\nSending Headers = {User-Agent: my-python-script} to https://httpbin.org/headers : \n")
print(r.text)
