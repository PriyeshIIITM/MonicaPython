import win32com.client as win32
import os

FILE_PATH = os.path.expanduser(r"~\Desktop\EmployeeDataMenu.xlsx")

def start_excel():
    excel = win32.gencache.EnsureDispatch("Excel.Application")
    excel.Visible = False
    return excel

def create_excel():
    excel = start_excel()
    wb = excel.Workbooks.Add()
    ws = wb.Sheets(1)
    ws.Name = "Employees"
    ws.Range("A1").Value = "Name"
    ws.Range("B1").Value = "Salary"
    ws.Range("C1").Value = "Department"
    wb.SaveAs(FILE_PATH)
    wb.Close()
    excel.Quit()
    print("Excel file created.")

def insert_record(name, salary, dept):
    excel = start_excel()
    wb = excel.Workbooks.Open(FILE_PATH)
    ws = wb.Sheets("Employees")
    last_row = ws.Cells(ws.Rows.Count, 1).End(-4162).Row
    ws.Cells(last_row + 1, 1).Value = name
    ws.Cells(last_row + 1, 2).Value = salary
    ws.Cells(last_row + 1, 3).Value = dept
    wb.Save()
    wb.Close()
    excel.Quit()
    print("Record inserted.")

def read_all():
    excel = start_excel()
    wb = excel.Workbooks.Open(FILE_PATH)
    ws = wb.Sheets("Employees")
    last_row = ws.Cells(ws.Rows.Count, 1).End(-4162).Row
    print("\nAll Employee Records:")
    for i in range(2, last_row + 1):
        name = ws.Cells(i, 1).Value
        salary = ws.Cells(i, 2).Value
        dept = ws.Cells(i, 3).Value
        print(f"{i-1}. {name} - ₹{salary} - {dept}")
    wb.Close()
    excel.Quit()

def update_record(name, new_salary, new_dept):
    excel = start_excel()
    wb = excel.Workbooks.Open(FILE_PATH)
    ws = wb.Sheets("Employees")
    last_row = ws.Cells(ws.Rows.Count, 1).End(-4162).Row
    found = False
    for i in range(2, last_row + 1):
        if ws.Cells(i, 1).Value == name:
            ws.Cells(i, 2).Value = new_salary
            ws.Cells(i, 3).Value = new_dept
            found = True
            break
    if found:
        wb.Save()
        print("Record updated.")
    else:
        print("Name not found.")
    wb.Close()
    excel.Quit()

def delete_record(name):
    excel = start_excel()
    wb = excel.Workbooks.Open(FILE_PATH)
    ws = wb.Sheets("Employees")
    last_row = ws.Cells(ws.Rows.Count, 1).End(-4162).Row
    deleted = False
    for i in range(2, last_row + 1):
        if ws.Cells(i, 1).Value == name:
            ws.Rows(i).Delete()
            deleted = True
            break
    if deleted:
        wb.Save()
        print("Record deleted.")
    else:
        print("Name not found.")
    wb.Close()
    excel.Quit()

def generate_chart():
    excel = start_excel()
    wb = excel.Workbooks.Open(FILE_PATH)
    ws = wb.Sheets("Employees")
    last_row = ws.Cells(ws.Rows.Count, 1).End(-4162).Row

    chart = ws.Shapes.AddChart2(251, win32.constants.xlColumnClustered, 400, 100, 400, 300).Chart
    chart.SetSourceData(ws.Range(f"A1:B{last_row}"))
    chart.HasTitle = True
    chart.ChartTitle.Text = "Salary by Employee"

    wb.Save()
    wb.Close()
    excel.Quit()
    print("Chart generated.")

def generate_pivot():
    excel = start_excel()
    wb = excel.Workbooks.Open(FILE_PATH)

    try:
        ws = wb.Sheets("Employees")
        last_row = ws.Cells(ws.Rows.Count, 1).End(-4162).Row
        pivot_ws = wb.Sheets.Add(After=wb.Sheets(wb.Sheets.Count))
        pivot_ws.Name = "PivotReport"

        data_range = ws.Range(f"A1:C{last_row}")
        pivot_range_address = f"'Employees'!R1C1:R{last_row}C3"

        pivot_table_cache = wb.PivotTableWizard(
            SourceType=win32.constants.xlDatabase,
            SourceData=pivot_range_address,
            TableDestination=pivot_ws.Range("A3"),
            TableName="EmpPivot"
        )
        pivot_table = pivot_ws.PivotTables("EmpPivot")

        pivot_table.PivotFields("Department").Orientation = win32.constants.xlRowField
        pivot_table.AddDataField(
            pivot_table.PivotFields("Salary"),
            "Average Salary",
            win32.constants.xlAverage
        )
        pivot_table.PivotFields("Average Salary").NumberFormat = "₹#,##0"

        wb.Save()
        print("Pivot table created.")
    finally:
        wb.Close()
        excel.Quit()


# ---------- Menu ----------
while True:
    print("\nExcel Employee CRUD Menu")
    print("1. Create Excel File")
    print("2. Insert Record")
    print("3. Read All Records")
    print("4. Update Record by Name")
    print("5. Delete Record by Name")
    print("6. Generate Chart")
    print("7. Generate Pivot Table")
    print("8. Exit")

    choice = input("Enter your choice (1–8): ")

    if choice == "1":
        create_excel()
    elif choice == "2":
        name = input("Enter Name: ")
        salary = float(input("Enter Salary: "))
        dept = input("Enter Department: ")
        insert_record(name, salary, dept)
    elif choice == "3":
        read_all()
    elif choice == "4":
        name = input("Enter Name to Update: ")
        salary = float(input("Enter New Salary: "))
        dept = input("Enter New Department: ")
        update_record(name, salary, dept)
    elif choice == "5":
        name = input("Enter Name to Delete: ")
        delete_record(name)
    elif choice == "6":
        generate_chart()
    elif choice == "7":
        generate_pivot()
    elif choice == "8":
        print("Exiting...")
        break
    else:
        print("Invalid choice. Try again.")
