import win32com.client as win32
import os

# Sample employee data
data = [
    ["Name", "Salary", "Department"],
    ["Alice", 70000, "IT"],
    ["Bob", 60000, "HR"],
    ["Charlie", 80000, "Finance"],
    ["David", 75000, "Sales"],
    ["Eva", 72000, "IT"]
]

# Start Excel : Launch Excel
# Launches Excel in the background using COM automation.
# Visible = False runs it in hidden mode. Change to True for debugging.
excel = win32.gencache.EnsureDispatch("Excel.Application")
excel.Visible = False  # Make True if you want to see Excel

# Create a workbook and select the first sheet
wb = excel.Workbooks.Add()  # Adds a new Excel workbook.
ws = wb.Sheets(1)
ws.Name = "Report"   # Accesses the first sheet and renames it to "Report".

# Write data to cells
# enumerate(..., start=1) ensures row/column indices start at 1 (Excel-style).
for row_idx, row in enumerate(data, start=1):
    for col_idx, value in enumerate(row, start=1):
        ws.Cells(row_idx, col_idx).Value = value

# Formatting headers (first row)
header_range = ws.Range("A1:C1")
header_range.Font.Bold = True
header_range.Interior.ColorIndex = 36  # Light yellow
header_range.Font.Size = 12

# Autofit columns
ws.Columns("A:C").AutoFit()

# Add a chart: Salary by Name
chart = ws.Shapes.AddChart2(251, 5, 300, 100, 400, 300).Chart
chart.SetSourceData(Source=ws.Range("A1:B6"))
chart.ChartType = win32.constants.xlColumnClustered
chart.HasTitle = True
chart.ChartTitle.Text = "Employee Salary Report"

# Save the file
output_path = os.path.expanduser(r"~\Desktop\AllEmployeeDataWin32.xlsx")
wb.SaveAs(output_path)

# Cleanup
wb.Close(SaveChanges=0)
excel.Quit()

print(f"Excel report generated: {output_path}") # Excel report generated: C:\Users\monica\Desktop\AllEmployeeDataWin32.xlsx

